def handler(event, context):
    print("It's working")
